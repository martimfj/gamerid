package com.gamerid.gamerid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameridApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameridApplication.class, args);
	}
}
